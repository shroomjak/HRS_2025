import cv2 as cv 
import numpy as np
import time
import astropy.io.fits as asp
import matplotlib.pyplot as plt
import os
# from numba import njit


def center_of_mass(array):
    normalizer = np.sum(array.flatten())
    grids = np.ogrid[[slice(0, i) for i in array.shape]]

    results = [np.sum(array * grids[dir].astype(float)) / normalizer
               for dir in range(array.ndim)]

    if np.isscalar(results[0]):
        return tuple(results)
    return [tuple(v) for v in np.array(results).T]

directory = "./J2017" 
files = list(os.listdir(directory))
files.remove('background.fts')
fig, ax = plt.subplots(2, 1, figsize=(10, 20))
print(files)
means = []
all_angular = []
bin_centers = []
stds = []
sigma = []
for k, i in enumerate(files, 1):
    wl = asp.open(os.path.join(directory, i))
    raw = np.array(wl[0].data).astype(float)
    
    # get center of an image
    filtered = np.where(raw > 0, raw, 0)
    gray = (filtered - np.min(filtered)) / (np.max(filtered) - np.min(filtered)) * 255
    gray = gray.astype(np.uint8)
    hdr = wl[0].header
    # plt.imshow(gray)
    # plt.colorbar()
    blur = cv.GaussianBlur(gray, (9, 9), 0)

    y, x = np.ogrid[:gray.shape[0], :gray.shape[1]]
    # Calculate radial distance for each pixel
    c_y, c_x = center_of_mass(gray)

    #center_x, center_y = sorted(centers, key=lambda p: ((c_x-p[0])**2 + (c_y-p[1])**2))[0]
    center_x, center_y = round(c_x), round(c_y)
    phi = np.arctan2((y - center_y), (x - center_x))
    r = np.sqrt((x - center_x) ** 2 + (y - center_y) ** 2)
    
    
    # Define radial bins
    max_radius = np.min([center_x, center_y, gray.shape[1] - center_x, gray.shape[0] - center_y]) - 10
    # Define radial bins
    num_bins = 36 # Adjust as needed
    bins = np.linspace(-np.pi, np.pi, num_bins+1, endpoint=True)

    angular_intensity = np.zeros(num_bins)
    bin_centers = (bins[:-1] + bins[1:]) / 2
    for i in range(num_bins):
        mask = ((phi >= bins[i]) & (phi <= bins[i + 1]) & (r <= max_radius))
        # Calculate mean intensity for pixels within the current bin
        angular_intensity[i] = np.mean(raw.astype(float)[mask])

    mean = np.mean(angular_intensity)
    std = np.std(angular_intensity)
    ax[0].plot(bin_centers, angular_intensity - mean)
    ax[0].set_xlabel('Angle (rad)')
    ax[0].set_ylabel('Average Intensity')
    means.append(mean)
    stds.append(std)
    all_angular.append(angular_intensity)
    #m = np.min(angular_intensity)
    #M = np.max(angular_intensity)
    #plt.title(f'Angular Intensity Distribution,\n max eps = {max([M - mean, mean - m])/mean:.3f}, mean eps = {std/mean:.3f}, std = {std:.2f}, mean = {mean:.3f}')
    
    #plt.plot(bin_centers, [mean]*len(bin_centers))
    #plt.vlines([phi_min, phi_max], ymin = mean, ymax=[angular_intensity[np.argmin(angular_intensity)], angular_intensity[np.argmax(angular_intensity)]])

all_angular = np.array(all_angular)

sigma = np.std(all_angular, axis=0)
ax[1].plot(bin_centers, sigma / np.mean(all_angular, axis=0))
ax[1].set_xlabel('Angle (rad)')
ax[1].set_ylabel('Sigma intensity')
fig.suptitle(f'Angular Intensity Distribution, eps means = {np.std(means) / np.mean(means):.4f}, eps sigma = {np.max(sigma / all_angular):.4f}')
plt.grid(True)
plt.show()
    
    



    
    
    
    

