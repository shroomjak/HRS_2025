import cv2 as cv 
import numpy as np
import time
import astropy.io.fits as asp
import matplotlib.pyplot as plt
import os
# from numba import njit


def center_of_mass(array):
    normalizer = np.sum(array.flatten())
    grids = np.ogrid[[slice(0, i) for i in array.shape]]

    results = [np.sum(array * grids[dir].astype(float)) / normalizer
               for dir in range(array.ndim)]

    if np.isscalar(results[0]):
        return tuple(results)
    return [tuple(v) for v in np.array(results).T]

directory = "./no_noise_HIP96258_1" 
#bw = asp.open('./J2017/background.fts')
#background = np.array(bw[0].data)
#bw.close()

files = os.listdir(directory)
#files.remove('background.fts')
all_radial = []
bin_centers = []
means = []
fig, ax = plt.subplots(2, 1, figsize=(10, 20))
for k, i in enumerate(files, 1):
    wl = asp.open(os.path.join(directory, i))
    raw = np.array(wl[0].data).astype(float)
    
    # get center of an image
    filtered = np.where(raw > 0, raw, 0)
    gray = filtered / np.max(filtered) * 255
    gray = gray.astype(np.uint8)
    hdr = wl[0].header
    # plt.imshow(gray)
    # plt.colorbar()
    blur = cv.GaussianBlur(gray, (9, 9), 0)
    ret, binary = cv.threshold(blur, 0, 255, cv.THRESH_OTSU)

    y, x = np.ogrid[:binary.shape[0], :binary.shape[1]]
    c_y, c_x = center_of_mass(binary)

    #center_x, center_y = sorted(centers, key=lambda p: ((c_x-p[0])**2 + (c_y-p[1])**2))[0]
    center_x, center_y = round(c_x), round(c_y)
    # Calculate radial distance for each pixel
    r = np.sqrt((x - center_x) ** 2 + (y - center_y) ** 2)
    
    # Define radial bins
    max_radius = np.min([center_x, center_y, binary.shape[1] - center_x, binary.shape[0] - center_y])
    num_bins = 25
    bins = np.linspace(0, max_radius, num_bins + 1)

    radial_intensity = np.zeros(num_bins)
    bin_centers = (bins[:-1] + bins[1:]) / 2
    print(k)
    for i in range(num_bins):
        mask = (r >= bins[i]) & (r <= bins[i + 1])
        radial_intensity[i] = np.mean(raw[mask])
    mean = np.mean(radial_intensity) 
    means.append(mean)
    all_radial.append(radial_intensity)
    ax[0].plot(bin_centers, radial_intensity)
    ax[0].set_xlabel('Radial Distance (pixels)')
    ax[0].set_ylabel('Average Intensity')
    wl.close()

all_radial = np.array(all_radial)

sigma = np.std(all_radial, axis=0)
ax[1].plot(bin_centers, sigma / np.mean(all_radial, axis=0))
ax[1].set_xlabel('Radial Distance (pixels)')
ax[1].set_ylabel('Sigma intensity')
fig.suptitle(f'Radial Intensity Distribution, eps means = {np.std(means) / np.mean(means):.2f}, eps sigma = {np.max(sigma / all_radial):.3f}')
plt.grid(True)
plt.show()
    
    



    
    
    
    

