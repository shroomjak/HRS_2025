#!/usr/bin/python3
# -*- coding: UTF-8 -*-
#author Zheltoukhov Sergey, Atapin Kirill

import time
import numpy as np
import os
import sys
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
from astropy.io import fits
import argparse
import datetime
import subprocess
import threading
from scipy import ndimage, signal, optimize

from matplotlib.figure import Figure 
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.backends.backend_tkagg import NavigationToolbar2Tk
import tkinter as Tk
from tkinter import ttk

import hikGrab

def do_quit():
	global stop_loop, Nframes 
	print('quit')
	stop_loop = True
	Nframes = 1
	my_thread.join() 
	_cam_down()
	print('down')
	root.quit()
	root.destroy()


def do_pause():
	global is_paused
	if is_paused:
		print("Resume...")
		is_paused = False
	else:
		print("Pause..")
		is_paused = True

	# pauseButton['text']='Wait..'
	# pauseButton['state']='disabled'

def do_save():
	hdu=fits.PrimaryHDU(img)
	hdu.header['exp']=namespace.exposition
	hdu.header['N']=Nframes
	hdu.header['TIME']=time.time()
	hdu.header['cam']='hikrobot camera'
	hdu.writeto(path_dir+'saved_imgs/'+datetime.datetime.now().strftime('%Y%m%dT%H%M%S')+'.fits' )

def do_HDR():
	global HDR_flag, HDRButton
	HDR_flag = ~ HDR_flag
	if HDR_flag:
		HDRButton['text']='NO!\nHDR'
	else:
		HDRButton['text']='HDR'

def do_apply_exp():
	global exposure
	exposure= int(exp_val.get())
	if exposure>EXP_MAX:
		exposure = EXP_MAX
	if exposure<25:
		exposure = 25
	rate = int(0.9e6/exposure)
	if rate<1:rate=1
	if rate>4:rate=4
	mycam.set_framerate(rate)
	mycam.set_exposure(exposure)
	exp_val.set(int(exposure))

def do_apply_N():
	global Nframes
	Nframes = int(N_frames_str.get())


def _camera_reload():
	global my_thread, stop_loop, Nframes, is_paused
#	pauseButton['state']='disabled'
#	reload_button['state']='disabled'
	stop_loop = True
	Nframes = 1
	my_thread.join() 
	time.sleep(0.1)
	_cam_down()
	time.sleep(0.1)
	stop_loop = False
	is_paused = False
	my_thread = threading.Thread(target = get_img)
	my_thread.start()
#	reload_button['state']='normal'


def _camera_init():
	global mycam, exposure, flir_active
	mycam = hikGrab.hikkamera()
#	mycam.init(serial='DA1809449')  #..:B1:39
	mycam.init(serial=namespace.serial)  # 'DA2037993' ..:89:21
	mycam.set_exposure(exposure)
	mycam.set_gain(19)
	mycam.set_framerate(4)
	# mycam.set_pixel_format('Mono12Packed')
	mycam.set_pixel_format(namespace.pixel)
	print('gotoSTART')
	mycam.start_grab()
	flir_active = True
	print('HIK camera up')

def _cam_down():
	global mycam
	mycam.stop_grab()
	mycam.exit()

	print('flir camera down')

def createParser():
	parser = argparse.ArgumentParser(prog='viwer.py', description ='KGO Hik camera wiever')
	parser.add_argument ('-e', '--exposition', type = float, default = EXP_MAX, help = 'Specify camera exposition in microseconds')
	parser.add_argument ('-N', '--Nframes', type = int, default = 1, help = 'Number of frames to summ')
	parser.add_argument ('-F', '--file', type = str, default = None, help = 'file for log')
	parser.add_argument ('-s', '--serial', type = str, default = '', help = 'serial')
	parser.add_argument ('-b', '--blure', action='store_const', const=True, default=False, help = 'blure hot pixels')
	parser.add_argument ('-p', '--pixel', type = str, default = 'Mono12', help = 'Mono12 Mono8 pixel format')
	return parser

def complete_frame():
	i_now = mycam.i_frames
	while i_now==mycam.i_frames:
		time.sleep(0.01)
		# print('cam_i_frames',mycam.i_frames)
	img_cam = mycam.sum_buff.copy().astype(float)
	# print('frame')
	return img_cam


def get_img():
	global i_frame, img, img_done, is_paused, mycam, flir_active, Nframes, title
	_camera_init()
	while not stop_loop:
		if not is_paused:
			if mycam is None:
				_camera_init()
			if not flir_active:
				flir_active=True
				# pauseButton['text']= 'Pause'
				# pauseButton['state']='normal'
			img_done = 0
			img_t = complete_frame()
			if Nframes>1:
				j=1
				while j < (Nframes+1):
					img_t += complete_frame()
					j+=1
			img_t=img_t/Nframes
			if namespace.blure:
				blured_img = ndimage.median_filter(img_t,3)
				difference = np.abs(img_t - blured_img)
				threshold = 2.5*np.nanstd(img_t - blured_img)
				pixels=np.where(difference>threshold)
	#			print(len(pixels[0]))
				img_t[pixels] = blured_img[pixels]
			img_done = 1
			img=img_t
			img_done = 2
			# dx=256
			# img_filt = img.copy()
			# img_filt[1024-dx:1024+dx,1024-dx:1024+dx] = -1
			# img_filt = img_filt[256:-256,256:-256]
			# ring_mean = np.mean(img_filt[img_filt>0])
			# ring_std = np.std(img_filt[img_filt>0])

			title = "frame #%d, mean=%f, signal=%d" % (i_frame ,img.mean(),np.sum(img) )
			# print('minmax',np.max(img),np.min(img))
			# print(title)

			if namespace.file is not None:
				ftowrite.write('{} {} {} {} {}\n'.format(i_frame,exposure,img.mean(),int(np.sum(img)),datetime.datetime.now()))

			i_frame+=1
		else:
			if flir_active:
				flir_active=False
				# pauseButton['text']= 'Resume'
				# pauseButton['state']='normal'

		time.sleep(0.05)

def _callback_mouse(event):
	global x_star,y_star,dx
	if event.button == 1:
		x_star, y_star = int(event.xdata), int(event.ydata)
		print('star',x_star, y_star)

EXP_MAX = 2499852
parser = createParser()
namespace = parser.parse_args()
path_dir = os.path.dirname(os.path.abspath(__file__) )+'/'
exposure = int(3e5)
Nframes = namespace.Nframes
# dark = fits.open(path_dir+'/master_dark.fits')[0].data
dark = 0
x_star = 500
y_star = 500
dx = 100

try:
	fits.open(path_dir+'/start.fits')[0].data
except:
	img = np.zeros((512,1024))
img_done = 0
mycam=None
flir_active = False
stop_loop = False
HDR_flag = False
title = 'Wait...'
i_frame = 0		#Frame counter

is_paused=False


my_thread = threading.Thread(target=get_img)
my_thread.start()

root = Tk.Tk()
root.wm_title("Hik GUI")

# icpath= path_dir+'/ico.png'
# root.tk.call('wm', 'iconphoto', root._w, Tk.PhotoImage(file=icpath) )

#Make the window resizable
Tk.Grid.rowconfigure(root, 0, weight=1)
Tk.Grid.columnconfigure(root, 0, weight=1)

frame_display = Tk.Frame(root,pady=5)		#Frame for the image
frame_display.grid(row=0, column=0)
frame_settings = Tk.Frame(root,pady=5)		#Frame for buttons and scales
frame_settings.grid(row=1, column=0)

frame_navigate = Tk.Frame(master=root)				#Frame for pyplot navigation pannel
frame_navigate.grid(row=2,column=0)

#Prepare buttons and scales
dx_val = Tk.StringVar(value='100')
exp_val = Tk.StringVar(value=exposure)
N_frames_str=Tk.StringVar(value='5')
min_val_str = Tk.StringVar(value='0')
max_val_str = Tk.StringVar(value='150')

# Tk.Label(frame_settings, text='N Frames:', anchor=Tk.W)
Tk.Entry(frame_settings,width=3,textvariable=N_frames_str).pack(side='left',padx=0,pady=(1,1))
Tk.Button(frame_settings, text="Apply\nN Frames", fg="blue", command=do_apply_N,height=2,width=6).pack(side='left',padx=2,pady=2)

# Tk.Label(frame_settings, text='Exp:', anchor=Tk.W).pack(side='left',padx=(15,1),pady=(15,1))
Tk.Entry(frame_settings,width=8,textvariable=exp_val).pack(side='left',padx=0,pady=(1,1))
Tk.Button(frame_settings, text="Apply\nExp", fg="blue", command=do_apply_exp,height=2,width=5).pack(side='left',padx=0,pady=2)

Tk.Label(frame_settings, text='Dx:', anchor=Tk.W).pack(side='left',padx=(2,1),pady=(2,1))
Tk.Entry(frame_settings,width=5,textvariable=dx_val).pack(side='left',padx=0,pady=(1,1))

Tk.Label(frame_settings, text='Min:', anchor=Tk.W).pack(side='left',padx=(10,1),pady=(2,1))
Tk.Entry(frame_settings,width=5,textvariable=min_val_str).pack(side='left',padx=0,pady=(1,1))
Tk.Label(frame_settings, text='Max:', anchor=Tk.W).pack(side='left',padx=(10,1),pady=(2,1))
Tk.Entry(frame_settings,width=5,textvariable=max_val_str).pack(side='left',padx=0,pady=(1,1))


HDRButton = Tk.Button(frame_settings, text="HDR", fg="blue", command=do_HDR,height=2,width=5)
HDRButton.pack(side='left',pady=2, padx=[2,2])
Tk.Button(frame_settings, text="Save\nimage", fg="blue", command=do_save,height=2,width=5).pack(side='left',padx=1,pady=2)


# pauseButton = Tk.Button(frame_settings, text="Wait..",state='disabled', fg="black", command=do_pause,height=2,width=5)
# pauseButton.pack(side='left',pady=2)
# reload_button = Tk.Button(frame_settings, text="Reload\ncamera", fg="blue", command=_camera_reload,height=2,width=5)
# reload_button.pack(side='left',pady=2)

Tk.Button(frame_settings, text="Quit", fg="red", command=do_quit,height=2,width=6).pack(side='right',padx=(30,2),pady=2)


# if namespace.noflir:
# 	pauseButton['text']='Resume'
# 	pauseButton['state']='normal'


#Prepare figure
# fig = Figure(figsize=(13,9))
# axes= fig.add_subplot(111)
fig = plt.figure(figsize=(13,8))
gs = fig.add_gridspec(2, 3)
# open axes/subplots
axs = []
axs.append( fig.add_subplot(gs[:,0:2]) ) # large subplot (2 rows, 2 columns)
axs.append( fig.add_subplot(gs[0,2]) )   # small subplot (1st row, 3rd column)
axs.append( fig.add_subplot(gs[1,2]) )   # small subplot (2nd row, 3rd column)

axs[1].set_title('Zoom')
axs[2].set_title('Zoom2')

if namespace.file is not None:
	ftowrite = open(namespace.file,'a')


canvas = FigureCanvasTkAgg(fig, master=frame_display)
canvas.get_tk_widget().pack()
fig.canvas.callbacks.connect('button_press_event', _callback_mouse)	#Catch mouse

#Navigations toolbox with coordinates
toolbar = NavigationToolbar2Tk(canvas, frame_navigate)
toolbar.update()


def infinite_loop():
	global i_frame, img, img_done, Nframes
	try:
		vmin= float(min_val_str.get())
		vmax= float(max_val_str.get())
	except:
		vmin=0
		vmax=150
	if vmin>vmax:
		vmin=vmax-1
	# if (vmin >= vmax):
	# 	vmin_val.set(value=vmax-1)
	if img_done != 1:
		axs[0].clear()
		axs[1].clear()	
		axs[2].clear()
		try:
			dx = int(dx_val.get())
			if dx<10:dx=10
		except:
			dx = 100
		try:
			img_crop = img[y_star-dx:y_star+dx,x_star-dx:x_star+dx]
			img_crop2 = img[y_star-dx//2:y_star+dx//2,x_star-dx//2:x_star+dx//2]
		except:
			root.after(100,infinite_loop)
			return

		if not HDR_flag:
			axs[0].imshow(img,cmap=plt.get_cmap('gray'),vmin=vmin,vmax=vmax)
			axs[1].imshow(img_crop,cmap=plt.get_cmap('gray'),vmin=vmin,vmax=vmax)
			axs[2].imshow(img_crop2,cmap=plt.get_cmap('gray'),vmin=vmin,vmax=vmax)
		else:
			axs[0].imshow(img,cmap=plt.get_cmap('gray'))
			axs[1].imshow(img_crop,cmap=plt.get_cmap('gray'))
			axs[2].imshow(img_crop2,cmap=plt.get_cmap('gray'))

	axs[0].set_title( title )
	plt.tight_layout()
	fig.canvas.draw()
	root.after(100,infinite_loop)

try:
	infinite_loop()
		
	root.mainloop()
except KeyboardInterrupt:
	#pass
	do_quit()


