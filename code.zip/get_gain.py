#!/usr/bin/python3
# -- coding: utf-8 --
import hikGrab
import sys
import threading
import os
import termios
import numpy as np 
import time
import astropy.io.fits as asp
import matplotlib.pyplot as plt

from ctypes import *

# add directory to path
sys.path.append("./MvImport")
from MvCameraControl_class import *

if __name__ == "__main__":
    mycam = hikGrab.hikkamera()
    mycam.init(serial='DA1309692')
    # mycam.set_framerate(30)
    mycam.set_black_level(0)
    mycam.set_gain(19)
	# mycam.set_pixel_format('Mono12Packed')
    mycam.set_pixel_format('Mono12')
    

    t0 = 1000
    t = t0

    for k in range(20):
        stt= time.time()
        mycam.set_exposure(t)

        print(k)
        mycam.getNframes(1)
        av_im1 = mycam.sum_buff
        mycam.getNframes(1)
        av_im2 = mycam.sum_buff
        filename_mean = f'./gain/mean/{t}.fts'
        filename_diff = f'./gain/diff/{t}.fts'
        hdu_diff = asp.PrimaryHDU(data=av_im1.astype(np.int16) - av_im2.astype(np.int16))
        hdr_diff = hdu_diff.header
        hdr_diff.append(('TIME', f'{stt}'))
        hdr_diff.append(('EXPOSURE', f'{t}'))
        
        hdu_mean = asp.PrimaryHDU(data=(av_im1.astype(np.int16) + av_im2.astype(np.int16)) / 2)
        hdr_mean = hdu_mean.header
        hdr_mean.append(('TIME', f'{stt}'))
        hdr_mean.append(('EXPOSURE', f'{t}'))
	    
#        hdu2 = asp.CompImageHDU(data=av_im)
#        hdul = asp.HDUList([hdu1, hdu2])
        hdu_diff.writeto(filename_diff, overwrite=True)
        hdu_mean.writeto(filename_mean, overwrite=True)

        t *= 1.05

    mycam.exit()

