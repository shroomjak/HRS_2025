import cv2 as cv 
import numpy as np
import time
import astropy.io.fits as asp
import matplotlib.pyplot as plt
from matplotlib.tri import Triangulation
import os
# from numba import njit


def avg_smooth(y, h):
    smoothed = np.zeros_like(y)
    for i in range(len(y)):
        num = len(np.arange(max(i-h, 0), min(i+h, len(y)), 1))
        smoothed[i] = np.sum(y[max(i-h, 0):min(i+h, len(y))])/num
    #smoothed[0] = smoothed[-1] = 0
    return smoothed


def center_of_mass(array):
    normalizer = np.sum(array.flatten())
    grids = np.ogrid[[slice(0, i) for i in array.shape]]

    results = [np.sum(array * grids[dir].astype(float)) / normalizer
               for dir in range(array.ndim)]

    if np.isscalar(results[0]):
        return tuple(results)
    return [tuple(v) for v in np.array(results).T]

directory = "./HIP96258_M2" 
files = os.listdir(directory)
#files.remove('background.fts')

bw = asp.open('./background/background.fts')
background = np.array(bw[0].data)

means = []
all_radial = []
bin_centers = []
stds = []
sigma = []
data_M2 = []
time = []

for k, i in enumerate(files, 1):
    wl = asp.open(os.path.join(directory, i))
    raw = np.array(wl[0].data).astype(float) - background.astype(float)
    
    # get center of an image
    filtered = np.where(raw > 0, raw, 0)
    gray = (filtered - np.min(filtered)) / (np.max(filtered) - np.min(filtered)) * 255
    gray = gray.astype(np.uint8)
    hdr = wl[0].header
    # plt.imshow(gray)
    # plt.colorbar()
    blur = cv.GaussianBlur(gray, (9, 9), 0)
    ret, binary = cv.threshold(blur, 0, 255, cv.THRESH_BINARY+cv.THRESH_OTSU)

    time.append(float(hdr['TIME']))
    data_M2.append(float(hdr['M2']))

    y, x = np.ogrid[:binary.shape[0], :binary.shape[1]]
    c_y, c_x = center_of_mass(binary)

    #center_x, center_y = sorted(centers, key=lambda p: ((c_x-p[0])**2 + (c_y-p[1])**2))[0]
    center_x, center_y = round(c_x), round(c_y)
    # Calculate radial distance for each pixel
    r = np.sqrt((x - center_x) ** 2 + (y - center_y) ** 2)
    
    # Define radial bins
    max_radius = np.min([center_x, center_y, binary.shape[1] - center_x, binary.shape[0] - center_y])
    num_bins = 50
    bins = np.linspace(0, max_radius, num_bins + 1)

    # make radial intensity distribution 
    radial_intensity = np.zeros(num_bins)
    bin_centers = (bins[:-1] + bins[1:]) / 2
    print(k)
    for i in range(num_bins):
        mask = (r >= bins[i]) & (r < bins[i + 1])
        radial_intensity[i] = np.mean(raw[mask])

    mean = np.mean(radial_intensity)
    std = np.std(radial_intensity)
    means.append(mean)
    stds.append(std)
    all_radial.append(np.array(radial_intensity) / radial_intensity.max())
    #m = np.min(angular_intensity)
    #M = np.max(angular_intensity)
    #plt.title(f'Angular Intensity Distribution,\n max eps = {max([M - mean, mean - m])/mean:.3f}, mean eps = {std/mean:.3f}, std = {std:.2f}, mean = {mean:.3f}')
    
    #plt.plot(bin_centers, [mean]*len(bin_centers))
    #plt.vlines([phi_min, phi_max], ymin = mean, ymax=[angular_intensity[np.argmin(angular_intensity)], angular_intensity[np.argmax(angular_intensity)]])

all_radial = np.array(all_radial)


data_M2_unique = list(dict.fromkeys(data_M2))
facecolors = plt.colormaps['viridis_r'](np.linspace(0, 1, len(data_M2_unique)))
all_radial_dict_M2 = dict()
for i, M2 in enumerate(data_M2):
    all_radial_dict_M2[M2] = all_radial_dict_M2.get(M2, []) + [all_radial[i]]


#ax = plt.figure().add_subplot(projection='3d')
#all_radial_unique = [np.mean(all_radial_dict_M2[M2], axis=0) for M2 in data_M2_unique]

'''
for i, M2 in enumerate(data_M2_unique):
    ax.fill_between(bin_centers, M2, all_radial_unique[i],
                    bin_centers, M2, 0,
                    facecolors=facecolors[i], alpha=.7)


'''
fig, ax = plt.subplots()
all_radial_unique = np.array([np.mean(all_radial_dict_M2[M2], axis=0) for M2 in sorted(data_M2_unique)])

#print(all_radial_unique)
data_M2 = np.array(sorted(data_M2_unique))
[RADII, FOCII] = np.meshgrid(bin_centers, data_M2)
# tri = Triangulation(RADII.ravel(), FOCII.ravel())


# ax.plot_trisurf(tri, all_radial_unique.ravel(), cmap='plasma', edgecolor='none', antialiased=True)
contourf_ = ax.contourf(RADII, FOCII, all_radial_unique, 100, cmap='plasma')
# c_data = ax.contour(RADII, FOCII, all_radial_unique, levels=[0.9],  colors=('k',), linestyles=('-',), alpha=(0.0, ))


radii = bin_centers[np.argmax(all_radial_unique, axis=1)]
print(radii.shape, data_M2.shape)
smooth_radii = avg_smooth(radii, 3)

n_opt = np.argmax(smooth_radii)
M2_opt = data_M2[n_opt]
r_opt = smooth_radii[n_opt]

print()
ax.scatter(r_opt, M2_opt, color='red', marker='o', s=100)

ax.plot(smooth_radii, data_M2)
ax.hlines(y=M2_opt, xmin=np.min(bin_centers), xmax=r_opt, color='r', linestyle='-')
print(r_opt, np.min(r))
ax.set_title(f'Radial distribution(M2, time), Optimum M2: {M2_opt}')
ax.set_xlabel('Radius, px')
ax.set_ylabel('M2')
fig.colorbar(contourf_)
# ax.set_zlabel('Intensity');
plt.show()
    



    
    
    
    

