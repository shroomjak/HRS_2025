import numpy as np 
import time
import astropy.io.fits as asp
import matplotlib.pyplot as plt
import os
from copy import deepcopy
from scipy.optimize import curve_fit

diffs = os.listdir('./gain/diff')
disps = []
w = 200
for i in diffs:
    wl = asp.open(os.path.join('./gain/diff', i))
    
    data = wl[0].data
    cx, cy = data.shape
    pic = data[cx//2-2*w: cx//2, cy//2-2*w: cy//2]
    sigma = np.std(pic.flatten()) ** 2
    disps.append(sigma)
    
    wl.close()

means = []
signs = os.listdir('./gain/mean')
for i in signs:
    wl = asp.open(os.path.join('./gain/mean', i))

    data = wl[0].data
    cx, cy = data.shape
    pic = data[cx//2-2*w: cx//2, cy//2-2*w: cy//2]
    mean = np.mean(pic.flatten())
    means.append(mean)
    
    wl.close()
    
plt.scatter(means, disps)
plt.grid()
plt.xlabel('mean')
plt.ylabel('disp')

def func(x,a,b):
    return a + b*x

x = np.array(means)
y = np.array(disps)

popt, pcov = curve_fit(func, x, y)
plt.plot(x, func(x, *popt))
plt.title(f'gain = {2/popt[1]}, r = {2/popt[1] * np.sqrt(-popt[0]/2)}')

plt.show()
    

    
    
    
    

