import hikGrab
import sys
import threading
import os
import termios
import numpy as np 
import time
import astropy.io.fits as asp
import matplotlib.pyplot as plt
import serial
from datetime import datetime  

from ctypes import *

# add directory to path
sys.path.append("./MvImport")
from MvCameraControl_class import *



if __name__ == "__main__":
    t = 2000
    gain = 19
    fps = 50

    mycam = hikGrab.hikkamera()
    mycam.init(serial='DA1309692')
    mycam.set_exposure(t)
    mycam.set_gain(gain)
    mycam.set_framerate(fps)
    mycam.set_black_level(0)
    mycam.set_pixel_format('Mono12')
    mycam.set_Decimation(2)

	# mycam.set_ROI(400,400,400,400)
	# mycam.add_callback(simple_image_callback)
    
    need_back = True

    if need_back:
        stt= time.time()
        mycam.getNframes(100)
	    
        filename = f'./speed_background/background.fts'
        av_im = mycam.sum_buff/100
        hdu1 = asp.PrimaryHDU(data=av_im.astype(np.int16))
        hdr = hdu1.header
        hdr.append(('TIME', f'{stt}'))
        hdr.append(('EXPOSURE', f'{t}'))
        hdr.append(('GAIN', f'{gain}'))
        hdu1.writeto(filename, overwrite=True)
    
    data = []
    ser = serial.Serial('/dev/ttyUSB0', 115200)
    # hand = True
    start = time.time()
    n = int(input('pack: '))
    it = int(input('iterations: '))
    for i in range(it):
        ser.write('2\n'.encode())
        #decoded_response = ser.readline()
        # print(f'response: {decoded_response}')
        # time.sleep(1)
                    
        stt1 = time.time()
        mycam.getNframes3D(n)
        print('1. time, fps',time.time()-stt1, n/(time.time()-stt1))
        data.extend(mycam.buff_3D)

        ser.write('1\n'.encode())
        stt2 = time.time()
        mycam.getNframes3D(n)
        print('2. time, fps',time.time()-stt2, n/(time.time()-stt2))
        # decoded_response = ser.readline()
        # print(f'response: {decoded_response}')
        data.extend(mycam.buff_3D)
        print(i)

    filename = f'./calibration_speed/my_image{start}.fts'
    hdu1 = asp.PrimaryHDU(data=data)
    hdr = hdu1.header
    hdr.append(('TIME', f'{start}'))
    hdr.append(('FPS', f'{fps}'))
    hdr.append(('EXPOSURE', f'{t}'))
    hdr.append(('GAIN', f'{gain}'))
    hdr.append(('PACK', f'{n}'))
    #   hdu2 = asp.CompImageHDU(data=av_im)
    #   hdul = asp.HDUList([hdu1, hdu2])
    hdu1.writeto(filename, overwrite=True)
    # if delay > 0:
    #     time.sleep(delay)

    # ser.close()
    mycam.exit()