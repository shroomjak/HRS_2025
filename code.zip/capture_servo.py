import hikGrab
import sys
import threading
import os
import termios
import numpy as np 
import time
import astropy.io.fits as asp
import matplotlib.pyplot as plt
import serial
from epics import caget
from datetime import datetime  

from ctypes import *

# add directory to path
sys.path.append("./MvImport")
from MvCameraControl_class import *



if __name__ == "__main__":
    t = 1e5
    gain = 19
 
    mycam = hikGrab.hikkamera()
    mycam.init(serial='DA1309692')
    mycam.set_exposure(t)
    mycam.set_gain(gain)
    mycam.set_framerate(30)
    mycam.set_black_level(0)
    mycam.set_pixel_format('Mono12')
    mycam.set_Decimation(2)
    # mycam.set_pixel_format('Mono12Packed')
	# mycam.set_ROI(400,400,400,400)
	# mycam.add_callback(simple_image_callback)
    
	# mycam.start_grab()
	# mycam.wait_key()
	# time.sleep(10)
	# mycam.stop_grab()
    
    need_back = True
    ser = serial.Serial('/dev/ttyUSB0', 115200)
    if need_back:
        ser.write('1'.encode())
        stt= time.time()
        mycam.getNframes(10)
	    
        filename = f'./arktur_long/background.fts'
        av_im = mycam.sum_buff/10
        hdu = asp.PrimaryHDU(data=av_im.astype(np.int16))
        hdr = hdu.header
        hdr.append(('TIME', f'{stt}'))
        hdr.append(('EXPOSURE', f'{t}'))
        hdr.append(('GAIN', f'{gain}'))
        hdr.append(('M2',caget('SAI25:M2')))
        hdu.writeto(filename, overwrite=True)

   
    hand = True
    while((command := input()) != 'stop'):
        if command == 'hand':
            hand = True
            auto = False
        elif command == 'auto':
            auto = True
            hand = False
        else:
            print('Bad command')
            hand = auto = False
        if hand:
            ser.write(f'{input()}')
        if auto:     
            n = int(input('number: '))
            delay = int(input('delay: ')) 
            for i in range(n):
                ser.write('2'.encode())
                decoded_response = ser.readline()
                print(f'response: {decoded_response}')
                time.sleep(1)
                
                stt = time.time()
                mycam.getNframes(1)
                ser.write('1'.encode())
                decoded_response = ser.readline()
                print(f'response: {decoded_response}')
                # lent = time.time()-stt
	            
                filename = f'./arktur_long/my_image{stt}.fts'
                av_im = mycam.sum_buff
                hdu = asp.PrimaryHDU(data=av_im.astype(np.int16))
                hdr = hdu.header
                hdr.append(('TIME', f'{stt}'))
                hdr.append(('EXPOSURE', f'{t}'))
                hdr.append(('GAIN', f'{gain}'))
                hdr.append(('M2',caget('SAI25:M2')))
        #       hdu2 = asp.CompImageHDU(data=av_im)
        #       hdul = asp.HDUList([hdu1, hdu2])
                hdu.writeto(filename, overwrite=True)
                if delay > 0:
                    time.sleep(delay)
                print(i)
    
    ser.close()
    mycam.exit()

 


