import numpy as np 
import time
import astropy.io.fits as asp
import matplotlib.pyplot as plt
import os
from copy import deepcopy


# no_noise_directory = './no_noise_calibration'
#files = os.listdir(directory)
bw = asp.open('./speed_background/background.fts')
background = np.sum(bw[0].data.ravel())
 
wl = asp.open('/home/shef/Desktop/ilia/calibration_speed/my_image1752695865.82793.fts')

data = wl[0].data
# hdu.writeto(os.path.join(no_noise_directory, i), overwrite=True)
hdr = wl[0].header
time = float(hdr['TIME'])
fps = float(hdr['FPS'])
pack = int(hdr['PACK'])
# time = float(i.lstrip('my_image').rstrip('.fts'))
# print(time)
print(data.shape)
wl.close()
size = data.shape[0]

times = np.arange(0, size) % (2 * pack) * 1.0/fps 
brightnesses = data.reshape(data.shape[0], -1).sum(axis=1) - background
    
wl.close()
    
plt.scatter(times, brightnesses)
plt.grid()
plt.xlabel('t, s')
plt.ylabel('integral brightness')
std = np.std(brightnesses)
mean = np.mean(brightnesses)
#plt.title(f'mean: {mean:.3e}, std: {std:.3e}, eps: {std/mean:.3e}, signal/back: {mean/background:.3e}')
plt.vlines(pack * 1.0/fps, ymin=np.min(brightnesses), ymax=np.max(brightnesses))
plt.show()

