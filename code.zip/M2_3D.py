import hikGrab
import sys
import threading
import os
import termios
import numpy as np 
import time
import astropy.io.fits as asp
import matplotlib.pyplot as plt
import serial
from epics import caget
from datetime import datetime  

from ctypes import *

# add directory to path
sys.path.append("./MvImport")
from MvCameraControl_class import *



if __name__ == "__main__":
    t = 2000
    gain = 19
    fps = 50
 
    mycam = hikGrab.hikkamera()
    mycam.init(serial='DA1309692')
    mycam.set_exposure(t)
    mycam.set_gain(gain)
    mycam.set_framerate(30)
    mycam.set_black_level(0)
    mycam.set_pixel_format('Mono12')
    mycam.set_Decimation(2)
    # mycam.set_pixel_format('Mono12Packed')
	# mycam.set_ROI(400,400,400,400)
	# mycam.add_callback(simple_image_callback)
    
	# mycam.start_grab()
	# mycam.wait_key()
	# time.sleep(10)
	# mycam.stop_grab()
    
    need_back = False

    if need_back:
        stt= time.time()
        mycam.getNframes(10)
	    
        filename = f'./HIP96258_M2/background.fts'
        av_im = mycam.sum_buff/10
        hdu1 = asp.PrimaryHDU(data=av_im.astype(np.int16))
        hdr = hdu1.header
        hdr.append(('TIME', f'{stt}'))
        hdr.append(('EXPOSURE', f'{t}'))
        hdr.append(('GAIN', f'{gain}'))

        hdu1.writeto(filename, overwrite=True)

    ser = serial.Serial('/dev/ttyUSB0', 115200)
    
    n = int(input('number: '))
    ser.write('2'.encode())
    for i in range(n):
        stt = time.time()    
        mycam.getNframes3D(10)
        filename = f'./HIP96258_M2/my_image{stt}.fts'
        av_im = mycam.buff_3D
        hdu1 = asp.PrimaryHDU(data=av_im.astype(np.int16))
        hdr = hdu1.header
        hdr.append(('TIME', f'{stt}'))
        hdr.append(('EXPOSURE', f'{t}'))
        hdr.append(('GAIN', f'{gain}'))
        hdr.append(('M2',caget('SAI25:M2')))
        #       hdu2 = asp.CompImageHDU(data=av_im)
        #       hdul = asp.HDUList([hdu1, hdu2])
        hdu1.writeto(filename, overwrite=True)
    ser.write('1'.encode())
    
    ser.close()
    mycam.exit()

 


