#!/usr/bin/python3
# -- coding: utf-8 --

import sys
import threading
import os
import termios
import numpy as np 
import time

from ctypes import *

sys.path.append("./MvImport")
from MvCameraControl_class import *


class hikkamera():
	def __init__(self):
		self.g_bExit = False
		self.i_frames = 0
		self.exposure = 0
		self.framerate = 0
		self.gain = 0
		self.maxExp = 0
		self.minExp = 0

		self.maxWidth = 0
		self.maxHeight = 0

		self.Nframes = 0
		self.NframesDone = False
		self.sum_buff = None
		self.buff_3D = None

		self.Width = 0
		self.Height = 0
		self.minWidth = 0
		self.minHeight = 0
		self.OffsetX = 0
		self.OffsetY = 0
		
		self.cam = None
		self.data_buf = None 
		self.hThreadHandle = None
		self.nPayloadSize = None
		
	def Mono_numpy8(self, data, nWidth, nHeight):
		data_ = np.frombuffer(data, count=int(nWidth * nHeight), dtype=np.uint8, offset=0)
		data_mono_arr = data_.reshape(nHeight, nWidth)
		# numArray = np.zeros([nWidth, nHeight], "uint8")
		# numArray[:, :] = data_mono_arr
		return data_mono_arr

	def Mono_numpy12(self, data, nWidth, nHeight):
		data_ = np.frombuffer(data, count=int(nWidth * nHeight), dtype=np.uint16, offset=0)
		data_mono_arr = data_.reshape(nHeight, nWidth)
		return data_mono_arr

	def Mono_numpy12p(self, stOutFrame):
		nNewsize = stOutFrame.stFrameInfo.nWidth * stOutFrame.stFrameInfo.nHeight * 2
		stConvertParam = MV_CC_PIXEL_CONVERT_PARAM()
		memset(byref(stConvertParam), 0, sizeof(stConvertParam))
		stConvertParam.nWidth = stOutFrame.stFrameInfo.nWidth
		stConvertParam.nHeight = stOutFrame.stFrameInfo.nHeight
		stConvertParam.pSrcData = stOutFrame.pBufAddr
		stConvertParam.nSrcDataLen = stOutFrame.stFrameInfo.nFrameLen
		stConvertParam.enSrcPixelType = stOutFrame.stFrameInfo.enPixelType
		stConvertParam.enDstPixelType = PixelType_Gvsp_Mono16 
		stConvertParam.pDstBuffer = (c_ubyte * nNewsize)()
		stConvertParam.nDstBufferSize = nNewsize
		ret = self.cam.MV_CC_ConvertPixelType(stConvertParam)
		if ret != 0:
			print ("convert pixel fail! ret[0x%x]" % ret)
			return
		# print("Convent OK")
		img_buff = (c_ubyte * stConvertParam.nDstLen)()
		memmove(byref(img_buff), stConvertParam.pDstBuffer, stConvertParam.nDstLen)
		return self.Mono_numpy12(img_buff, stOutFrame.stFrameInfo.nWidth, stOutFrame.stFrameInfo.nHeight)//16

	def work_thread(self, cam=0, pData=0, nDataSize=0):
		stOutFrame = MV_FRAME_OUT()
		memset(byref(stOutFrame), 0, sizeof(stOutFrame))
		print('nPayloadSize', self.nPayloadSize)
		i_frame_c = 0
		while True:
			ret = self.cam.MV_CC_GetImageBuffer(stOutFrame, int(1000+self.exposure//1000))
			if ret == 0:
	
				if i_frame_c==0:
					self.Width = stOutFrame.stFrameInfo.nWidth
					self.Height = stOutFrame.stFrameInfo.nHeight
					self.sum_buff = np.zeros((self.Height,self.Width)).astype(np.int32)
					if self.is_3D:
						self.buff_3D = np.zeros((self.Nframes,self.Height,self.Width)).astype(np.int16)
				#print ("get one frame: Width[%d], Height[%d], PixelType[0x%x], nFrameNum[%d]"  % (stOutFrame.stFrameInfo.nWidth, stOutFrame.stFrameInfo.nHeight, stOutFrame.stFrameInfo.enPixelType, stOutFrame.stFrameInfo.nFrameNum))
				
				if stOutFrame.stFrameInfo.enPixelType == PixelType_Gvsp_Mono12_Packed:
					g_numArray = self.Mono_numpy12p(stOutFrame)
				else:
					buf_cache = (c_ubyte * stOutFrame.stFrameInfo.nFrameLen)()
					memmove(byref(buf_cache), stOutFrame.pBufAddr, stOutFrame.stFrameInfo.nFrameLen)

				if stOutFrame.stFrameInfo.enPixelType == PixelType_Gvsp_Mono8:
					g_numArray = self.Mono_numpy8(buf_cache,stOutFrame.stFrameInfo.nWidth, stOutFrame.stFrameInfo.nHeight)
				if stOutFrame.stFrameInfo.enPixelType == PixelType_Gvsp_Mono12:
					g_numArray = self.Mono_numpy12(buf_cache,stOutFrame.stFrameInfo.nWidth, stOutFrame.stFrameInfo.nHeight)

				self.cam.MV_CC_FreeImageBuffer(stOutFrame)
				self.i_frames = stOutFrame.stFrameInfo.nFrameNum

				i_frame_c+=1
				if self.is_3D:
					self.buff_3D[i_frame_c-1] = g_numArray
				# if self.Nframes>0:
				self.sum_buff+=g_numArray
				if i_frame_c>=self.Nframes:
					self.NframesDone=True
					break
				# else:
				# 	self.sum_buff=g_numArray


			else:
				print ("no data[0x%x]" % ret)


			if self.g_bExit == True:
					break

	def press_any_key_exit(self):
		fd = sys.stdin.fileno()
		old_ttyinfo = termios.tcgetattr(fd)
		new_ttyinfo = old_ttyinfo[:]
		new_ttyinfo[3] &= ~termios.ICANON
		new_ttyinfo[3] &= ~termios.ECHO
		#sys.stdout.write(msg)
		#sys.stdout.flush()
		termios.tcsetattr(fd, termios.TCSANOW, new_ttyinfo)
		try:
			os.read(fd, 7)
		except:
			pass
		finally:
			termios.tcsetattr(fd, termios.TCSANOW, old_ttyinfo)

	def init(self,serial,is_print = True):
		deviceList = MV_CC_DEVICE_INFO_LIST()
		tlayerType = MV_GIGE_DEVICE | MV_USB_DEVICE
		
		#en:Enum device
		ret = MvCamera.MV_CC_EnumDevices(tlayerType, deviceList)
		if ret != 0:
			print ("enum devices fail! ret[0x%x]" % ret)
			return

		if deviceList.nDeviceNum == 0:
			print ("find no device!")
			return

		nConnectionNum = 0
		print ("Find %d devices!" % deviceList.nDeviceNum)
		for i in range(0, deviceList.nDeviceNum):
			mvcc_dev_info = cast(deviceList.pDeviceInfo[i], POINTER(MV_CC_DEVICE_INFO)).contents
			if mvcc_dev_info.nTLayerType == MV_GIGE_DEVICE:
				print ("\ngige device: [%d]" % i)
				strModeName = ""
				for per in mvcc_dev_info.SpecialInfo.stGigEInfo.chModelName:
					strModeName = strModeName + chr(per)
				print ("device model name: %s" % strModeName)
				chSerialNumber = ""
				for per in mvcc_dev_info.SpecialInfo.stGigEInfo.chSerialNumber:
					chSerialNumber = chSerialNumber + chr(per)
				# print(serial,len(serial),len(chSerialNumber.lstrip().rstrip()))
				if serial in chSerialNumber:
					print('My device') 
					nConnectionNum = i
				print ("device Serial number: %s" % chSerialNumber)
				nip1 = ((mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0xff000000) >> 24)
				nip2 = ((mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0x00ff0000) >> 16)
				nip3 = ((mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0x0000ff00) >> 8)
				nip4 = (mvcc_dev_info.SpecialInfo.stGigEInfo.nCurrentIp & 0x000000ff)
				print ("current ip: %d.%d.%d.%d\n" % (nip1, nip2, nip3, nip4))
			elif mvcc_dev_info.nTLayerType == MV_USB_DEVICE:
				print ("\nu3v device: [%d]" % i)
				strModeName = ""
				for per in mvcc_dev_info.SpecialInfo.stUsb3VInfo.chModelName:
					if per == 0:
						break
					strModeName = strModeName + chr(per)
				print ("device model name: %s" % strModeName)

				strSerialNumber = ""
				for per in mvcc_dev_info.SpecialInfo.stUsb3VInfo.chSerialNumber:
					if per == 0:
						break
					strSerialNumber = strSerialNumber + chr(per)
				print ("user serial number: %s" % strSerialNumber)

		# nConnectionNum = 0
		self.cam = MvCamera()
		
		#Select device and create handle
		stDeviceList = cast(deviceList.pDeviceInfo[int(nConnectionNum)], POINTER(MV_CC_DEVICE_INFO)).contents

		ret = self.cam.MV_CC_CreateHandle(stDeviceList)
		if ret != 0:
			print ("create handle fail! ret[0x%x]" % ret)
			sys.exit()

		# en:Open device
		ret = self.cam.MV_CC_OpenDevice(MV_ACCESS_Exclusive, 0)
		if ret != 0:
			print ("open device fail! ret[0x%x]" % ret)
			sys.exit()
		
		# en:Detection network optimal package size(It only works for the GigE camera)
		if stDeviceList.nTLayerType == MV_GIGE_DEVICE:
			nPacketSize = self.cam.MV_CC_GetOptimalPacketSize()
			if int(nPacketSize) > 0:
				ret = self.cam.MV_CC_SetIntValue("GevSCPSPacketSize",nPacketSize)
				if ret != 0:
					print ("Warning: Set Packet Size fail! ret[0x%x]" % ret)
			else:
				print ("Warning: Get Packet Size fail! ret[0x%x]" % nPacketSize)

		#en:Set trigger mode as off
		ret = self.cam.MV_CC_SetEnumValue("TriggerMode", MV_TRIGGER_MODE_OFF)
		if ret != 0:
			print ("set trigger mode fail! ret[0x%x]" % ret)
			sys.exit()


		self.get_exposure()
		self.get_framerate()
		self.get_gain()
		self.maxWidth, nmin, nmax = self.get_int("WidthMax")
		self.maxHeight, nmin, nmax = self.get_int("HeightMax")
		_,self.minWidth,_ = self.get_int('Width')
		_,self.minHeight,_ = self.get_int('Height')

		print('width',self.minWidth,self.maxWidth)
		print('height',self.minHeight,self.maxHeight)


		self.reset_ROI()
		# self.Width = self.maxWidth
		# self.Height = self.maxHeight
		# self.OffsetX = 0
		# self.OffsetY = 0
		self.set_enum('ExposureAuto','Off')
		self.set_enum('GainAuto','Off')
		self.set_enum('AcquisitionMode','Continuous')
		self.set_enum('TriggerMode','Off')

		# print('autoexp', self.get_enum('ExposureAuto'))
		# print("",self.get_bool('AutoExposureTimeLowerLimit'))


	def set_ROI(self,OffsetX,OffsetY,Width,Height):
		self.set_int('Width',Width)
		self.set_int('Height',Height)
		self.set_int('OffsetX',OffsetX)
		self.set_int('OffsetY',OffsetY)
		self.Width = Width
		self.Height = Height
		self.OffsetX = OffsetX
		self.OffsetY = OffsetY

	def reset_ROI(self):
		self.set_ROI(0,0,self.maxWidth,self.maxHeight)

	def set_pixel_format(self,ff):
		# 0x01080001:Mono8
		# 0x01100003:Mono10
		# 0x010C0004:Mono10Packed
		# 0x01100005:Mono12
		# 0x010C0006:Mono12Packed
		# 0x01100007:Mono16
		# 0x02180014:RGB8Packed
		# 0x02100032:YUV422_8
		# 0x0210001F:YUV422_8_UYVY
		# 0x01080008:BayerGR8
		# 0x01080009:BayerRG8
		# 0x0108000A:BayerGB8
		# 0x0108000B:BayerBG8
		# 0x0110000e:BayerGB10
		# 0x01100012:BayerGB12
		# 0x010C002C:BayerGB12Packed 
		self.set_enum('PixelFormat',ff)
		pass
		#PixelType_Gvsp_Mono12_Packed

	def set_black_level(self,level):
		self.set_bool('BlackLevelEnable',True)
		self.set_int('BlackLevel',level)

	def get_float(self, name):
		stParam =  MVCC_FLOATVALUE()
		memset(byref(stParam), 0, sizeof(MVCC_FLOATVALUE))
		
		ret = self.cam.MV_CC_GetFloatValue(name, stParam)
		if ret != 0:
			print (name, "get float fail! ret[0x%x]" % ret)
			# sys.exit()
			return np.NaN, np.NaN, np.NaN
		return stParam.fCurValue,stParam.fMin,stParam.fMax

	def set_float(self, name, val):
		ret = self.cam.MV_CC_SetFloatValue(name, val)
		if ret != 0:
			print (name, "set float fail! ret[0x%x]" % ret)
			# sys.exit()
			return -1
		return 0

	def set_bool(self, name, val):
		ret = self.cam.MV_CC_SetBoolValue(name, val)
		if ret != 0:
			print (name, "set bool fail! ret[0x%x]" % ret)
			# sys.exit()
			return -1
		return 0

	def get_int(self, name):
		stParam =  MVCC_INTVALUE()
		memset(byref(stParam), 0, sizeof(MVCC_INTVALUE))
		
		ret = self.cam.MV_CC_GetIntValue(name, stParam)
		if ret != 0:
			print (name,"get int fail! ret[0x%x]" % ret)
			# sys.exit()
			return np.NaN, np.NaN, np.NaN
		return stParam.nCurValue,stParam.nMin,stParam.nMax

	def set_int(self, name, val):
		ret = self.cam.MV_CC_SetIntValue(name, int(val))
		if ret != 0:
			print (name, "set int fail! ret[0x%x]" % ret)
			# sys.exit()
			return -1
		return 0

	def get_enum(self, name):
		stParam =  MVCC_ENUMENTRY()
		memset(byref(stParam), 0, sizeof(MVCC_ENUMENTRY))
		
		ret = self.cam.MV_CC_GetEnumEntrySymbolic(name, stParam)
		if ret != 0:
			print (name, "get enum fail! ret[0x%x]" % ret)
			# sys.exit()
			return np.NaN, np.NaN, np.NaN
		return stParam.nValue,stParam.chSymbolic

	def set_enum(self, name, val):
		ret = self.cam.MV_CC_SetEnumValueByString(name, val)
		if ret != 0:
			print (name, "set enum fail! ret[0x%x]" % ret)
			# sys.exit()
			return -1
		return 0
	# def get_bool(self, name):
	# 	stParam = c_bool
	# 	memset(byref(stParam), 0, sizeof(c_uint))
		
	# 	ret = self.cam.MV_CC_GetBoolValue(name, stParam)
	# 	if ret != 0:
	# 		print ("get bool fail! ret[0x%x]" % ret)
	# 		# sys.exit()
	# 		return np.NaN
	# 	return stParam

	def set_binning(self,binval):
		if binval not in [1,2,4]:
			print('binval mast bin 1 or 2 or 4')
		self.set_enum('BinningHorizontal','BinningHorizontal'+str(binval))
		self.set_enum('BinningVertical','BinningVertical'+str(binval))
		# self.get_enum('BinningVertical')

	def set_Decimation(self,binval):
		if binval not in [1,2]:
			print('Decimation mast bin 1 or 2 or 4')
		self.set_enum('DecimationHorizontal','DecimationHorizontal'+str(binval))
		self.set_enum('DecimationVertical','DecimationVertical'+str(binval))


	def get_exposure(self):
		self.exposure, self.minExp, self.maxExp = self.get_float("ExposureTime")
		print('exposure:',self.exposure, self.minExp, self.maxExp)

	def set_exposure(self,val):
		if self.set_float('ExposureTime',val) == 0:
			self.exposure = val

	def get_framerate(self):
		self.framerate, fmax, fmin = self.get_float("AcquisitionFrameRate")
		print('framerate:',self.framerate, fmax, fmin)

	def set_framerate(self,val):
		if self.set_float('AcquisitionFrameRate',val) == 0:
			self.framerate = val

	def get_gain(self):
		self.gain, fmax, fmin = self.get_float("Gain")
		print('gain:',self.gain, fmax, fmin)

	def set_gain(self,val):
		if self.set_float('Gain',val) == 0:
			self.gain = val

	def add_callback(self,func):
			winfun_ctype = CFUNCTYPE
			stFrameInfo = POINTER(MV_FRAME_OUT_INFO_EX)
			pData = POINTER(c_ubyte)
			FrameInfoCallBack = winfun_ctype(None, pData, stFrameInfo, c_void_p)
			CALL_BACK_FUN = FrameInfoCallBack(func)
			ret = self.cam.MV_CC_RegisterImageCallBackEx(CALL_BACK_FUN,None)
			if ret != 0:
				print ("register image callback fail! ret[0x%x]" % ret)
				return

	def getNframes(self, N=10):
		self.is_3D = False
		print('start', N)
		self.Nframes = N
		self.NframesDone = False
		self.start_grab()
		while not self.NframesDone:
			time.sleep(0.1)
		self.stop_grab()
		# time.sleep(1)
		print(self.Nframes,'frames Done')

	def getNframes3D(self, N=10):
		self.is_3D = True
		print('start', N)
		self.Nframes = N
		self.NframesDone = False
		self.start_grab()
		while not self.NframesDone:
			time.sleep(0.1)
		self.stop_grab()
		# time.sleep(1)
		print(self.Nframes,'frames Done')


	def start_grab(self, is_thread=True):
		self.g_bExit = False
		stParam =  MVCC_INTVALUE()
		memset(byref(stParam), 0, sizeof(MVCC_INTVALUE))
		
		ret = self.cam.MV_CC_GetIntValue("PayloadSize", stParam)
		if ret != 0:
			print ("get payload size fail! ret[0x%x]" % ret)
			sys.exit()

		self.nPayloadSize = stParam.nCurValue

		ret = self.cam.MV_CC_StartGrabbing()
		if ret != 0:
			print ("start grabbing fail! ret[0x%x]" % ret)
			sys.exit()

		if is_thread:
			self.data_buf = (c_ubyte * self.nPayloadSize)()
			try:
				self.hThreadHandle = threading.Thread(target=self.work_thread, args=(self.cam, byref(self.data_buf), self.nPayloadSize))
				self.hThreadHandle.start()
			except:
				print ("error: unable to start thread")

	def stop_grab(self):
		# ch:停止取流 | en:Stop grab image
		self.g_bExit = True
		self.hThreadHandle.join()

		ret = self.cam.MV_CC_StopGrabbing()
		if ret != 0:
			print ("stop grabbing fail! ret[0x%x]" % ret)
			del self.data_buf
			return		

	def wait_key(self):
		print ("press a key to stop grabbing.")
		self.press_any_key_exit()

	def exit(self):

		# ch:关闭设备 | Close device
		ret = self.cam.MV_CC_CloseDevice()
		if ret != 0:
			print ("close deivce fail! ret[0x%x]" % ret)
			del self.data_buf
			return

		# ch:销毁句柄 | Destroy handle
		ret = self.cam.MV_CC_DestroyHandle()
		if ret != 0:
			print ("destroy handle fail! ret[0x%x]" % ret)
			del self.data_buf
			return

		del self.data_buf


def simple_image_callback(pData, pFrameInfo, pUser):
	stFrameInfo = cast(pFrameInfo, POINTER(MV_FRAME_OUT_INFO_EX)).contents
	if stFrameInfo:
		print ("get one frame: Width[%d], Height[%d], nFrameNum[%d]" % (stFrameInfo.nWidth, stFrameInfo.nHeight, stFrameInfo.nFrameNum))


if __name__ == "__main__":

	mycam = hikkamera()
	mycam.init(serial='1309692')#DA1809449
	mycam.set_binning(1)
	mycam.set_Decimation(1)
	mycam.set_exposure(6000)
	mycam.set_gain(0)
	mycam.set_framerate(150)
	mycam.set_black_level(160)

	mycam.exit()
	exit()
	# mycam.set_pixel_format('Mono12Packed')
	# mycam.set_pixel_format('Mono12')
	# mycam.set_ROI(400,400,400,400)
	# mycam.add_callback(simple_image_callback)

	# mycam.start_grab()
	# mycam.wait_key()
	# time.sleep(10)
	# mycam.stop_grab()

	stt= time.time()
	mycam.getNframes3D(10)
	print(mycam.buff_3D,mycam.buff_3D.shape)
	lent = time.time()-stt
	print('time {}, fps {}'.format(lent, mycam.i_frames/lent))
	# mycam.getNframes(10)
	import matplotlib.pyplot as plt
	mycam.exit()
	plt.imshow(np.median(mycam.buff_3D,axis=0))
	plt.show()

