import numpy as np 
import time
import astropy.io.fits as asp
import matplotlib.pyplot as plt
import os
from copy import deepcopy

directory = "./calibration_speed" 
# no_noise_directory = './no_noise_calibration'
files = os.listdir(directory)
bw = asp.open('./background/background.fts')
background = np.sum(bw[0].data.ravel())
print(background)
times = []
brightnesses = []
for i in files:
    wl = asp.open(os.path.join(directory, i))

    hdu = asp.PrimaryHDU(data=wl[0].data)
    # hdu.writeto(os.path.join(no_noise_directory, i), overwrite=True)
    hdr = wl[0].header
    time = float(hdr['TIME']) 
    # time = float(i.lstrip('my_image').rstrip('.fts'))
    # print(time)
    times.append(time)
    brightness = np.sum(hdu.data.ravel())
    brightnesses.append(brightness)
    
    wl.close()
    
plt.scatter(times, brightnesses)
plt.grid()
plt.xlabel('t, s')
plt.ylabel('integral brightness')
std = np.std(brightnesses)
mean = np.mean(brightnesses)
plt.title(f'mean: {mean:.3e}, std: {std:.3e}, eps: {std/mean:.3e}, signal/back: {mean/background:.3e}')
plt.show()
