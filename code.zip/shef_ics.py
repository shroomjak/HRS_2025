#!/usr/bin/python3
# -*- coding: UTF-8 -*-
import time
import numpy as np
import os
import sys
import socket
import threading

port_ICSserver = 33023 # (It's my port on binary/ I'm ICS-server
ocs_client_connection = -1 # no connection from OCS as client
# OCS_IP = '192.168.15.51'  # OCS client for active commands to the telescope (protoOCS by now)
OCS_IP = '192.168.15.12'  # OCS client for active commands to the telescope OCSD
thread_ics = None

def ocs_send(cmd):
	global ocs_client_connection #, OCS_RUN_CURRENT
	print( 'server to OCS-client _send:->',cmd)
	if ocs_client_connection is -1:
		str_error = 'OCS-client connection is closed or not established yet'
		print(str_error)
		return -1
	try:
		ocs_client_connection.send((cmd+'\r').encode())
		return 0
	except socket.error:
		str_error = 'OCS-client connection is closed'
		print('icsmodule_send socket.error, closed connection?')
		try:
			if (ocs_client_connection is not -1): ocs_client_connection.close()
		except Exception as e:
			print( 'icsmodule:_send exception', e)

		ocs_client_connection = -1 
		return -1


def ocs_start_server(func=None):
	global ocs_client_connection, thread_ics
	global func_on_connect
	func_on_connect=func
	if ocs_client_connection is not -1:
		ocs_close()

	if thread_ics is None:
		thread_ics = threading.Thread(target = ics_server )
		thread_ics.daemon = True
		thread_ics.start()


def ics_server():
	global ocs_client_connection, sock, return_code, is_answer

	sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR, 1)

	try:
		sock.bind(('0.0.0.0', port_ICSserver))
		sock.listen(1)
		print( 'runICSserver: Socket is ready')
	except Exception as e:
		print('sock.bind or listen exception', e)
		return e

	while True:
		print( "ICS-server: Waiting for OCS-client connection...\n")
		#    ocs_client_connection, addr = sock.accept()
		ocs_client_connection_, addr = sock.accept()
		print( 'ICS-server has connected with OCS-client:', addr)
		if len(addr) > 1:
			ip_client = addr[0]
			print( "IP:", ip_client)
			if ip_client != OCS_IP:
				print( 'No, ip:', ip_client, ' is not my client. Disconnection')
				ocs_client_connection_.close()
				continue

			print( 'Yes! My client!')
			ocs_client_connection = ocs_client_connection_
			if func_on_connect is not None:
				try:
					func_on_connect()
				except:
					pass
			is_answer = 0
			return_code = 0
		while True:
			data = ocs_client_connection.recv(1024).decode()
			# res = re.sub('\n', '', re.sub('\r','', data))
			print( 'received: |'+data.rstrip().lstrip()+'|')
			try:
				return_code = int(data)
				is_answer = 1
			except ValueError:
				print('ERROR in data_code')
			if not data:
				print( 'icsmodule:OCS_Client_Thread: No data received from OCS, close')
				break

		if ocs_client_connection is not -1:
			try:
				print('icsmodule:OCS_Client_Thread tries close connection')
				ocs_client_connection.close()
			except Exception as e:
				print( 'icsmodule ClientThread exception', e, 'sock=', ocs_client_connection)
			print( 'ICS-server: OCS-client',addr,'has disconnected')
			ocs_client_connection = -1




def ocs_close():
	global ocs_client_connection
	print('Send Quit to OCS Client')
	try:
		ocs_send('quit')
	except Exception as e:
		print('Exception in Close:', e)

	if ocs_client_connection is not -1:
		ocs_client_connection.close()
		ocs_client_connection = -1


def block_wait_success():
	global is_answer, return_code
	while not is_answer:
		time.sleep(0.1)
	if return_code == 0 :
		is_answer = 0
		return 0
	else:
		print('error code', return_code )
		is_answer = 0
		return -1

def shiftHor(daz, dalt, is_block = False):    # in degrees
	global is_answer
	commstring = 'CORRECT DAZ ' + str(daz) + ' DALT ' + str(dalt)
	send_code = ocs_send(commstring)
	is_answer = 0
	if is_block and (send_code == 0):
		return block_wait_success()
	else:
		return send_code

def shiftEqu(dra, ddec, ddero=0, is_block = False):
	global is_answer
	commstring = 'SHIFTEQU DRA ' + str(dra) + ' DDEC ' + str(ddec) + ' DDERO ' + str(ddero)
	send_code = ocs_send(commstring)
	is_answer = 0
	if is_block and (send_code == 0):
		return block_wait_success()
	else:
		return send_code

def setFocus(m2pos, is_block = True):
	global is_answer
	commstring = 'FOCUS M2 ' + str(m2pos)
	send_code = ocs_send(commstring)
	is_answer = 0
	if is_block and (send_code == 0):
		return block_wait_success()
	else:
		return send_code

def targetDone(success=1):
	commstring = 'TARGETDONE SUCCESS ' + str(success)
	send_code = ocs_send(commstring)
	return send_code


def aguOn():
	commstring = 'AUTOGUIDE GUIDE 1'
	send_code = ocs_send(commstring)
	return send_code

def aguOff():
	commstring = 'AUTOGUIDE GUIDE 0'
	send_code = ocs_send(commstring)
	return send_code