import cv2 as cv 
import numpy as np
import time
import astropy.io.fits as asp
import matplotlib.pyplot as plt
import os

directory = "./star_test" 
files = os.listdir(directory)
sigma = []
all_radial = []
bin_centers = []
for i in files:
    wl = asp.open(os.path.join(directory, i))
    gray = np.array(wl[1].data).astype(float)
    gray /= np.max(gray)
    gray *= 255.0
    gray = gray.astype(np.uint8)
    hdr = wl[0].header

    blur = cv.GaussianBlur(gray, (9, 9), 0)
    ret, thresh = cv.threshold(blur, 0, 255, cv.THRESH_BINARY + cv.THRESH_OTSU)
   
    contours, _ = cv.findContours(thresh, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)
    centers = []
    for i in contours:
        M = cv.moments(i)
        if M['m00'] != 0:
            cx = int(M['m10']/M['m00'])
            cy = int(M['m01']/M['m00'])
            centers.append((cx, cy))

    y, x = np.ogrid[:gray.shape[0], :gray.shape[1]]
    
    '''    
    c_x = 0
    c_y = 0

    mass = gray.sum().sum()
    for xx in range(gray.shape[1]):
        for yy in range(gray.shape[0]):
            c_x += xx * gray[yy, xx].astype('float')
            c_y += yy * gray[yy, xx].astype('float')
    '''

    c_x = gray.shape[1] // 2
    c_y = gray.shape[0] // 2

    center_x, center_y = sorted(centers, key=lambda p: abs(c_x-p[0]) + abs(c_y-p[1]))[0]
    r = np.sqrt((x - center_x)**2 + (y - center_y)**2)
    
    # Define radial bins
    max_radius = np.min([center_x, center_y, gray.shape[1] - center_x, gray.shape[0] - center_y])
    num_bins = 50
    bins = np.linspace(0, max_radius, num_bins + 1)

    radial_intensity = np.zeros(num_bins)
    bin_centers = (bins[:-1] + bins[1:]) / 2
    print(bins)
    for i in range(num_bins):
        mask = (r >= bins[i]) & (r < bins[i + 1])
        radial_intensity[i] = np.mean(gray[mask])
    all_radial.append(radial_intensity)
    wl.close()
all_radial = np.array(all_radial).transpose()

for radial in all_radial:
    sigma.append(np.std(radial))

plt.scatter(bin_centers, sigma)
plt.xlabel('Radial Distance (pixels)')
plt.ylabel('Sigma')
plt.title('Radial Sigma Distribution')
plt.show()
    
    



    
    
    
    

