import hikGrab
import shef_ics

import sys
import threading
import os
import termios
import numpy as np 
import time
import astropy.io.fits as asp
import matplotlib.pyplot as plt
import serial
from epics import caget
from datetime import datetime  

from ctypes import *

# add directory to path
sys.path.append("./MvImport")
from MvCameraControl_class import *


def init_camera(serial_number, t, gain, fps, dec):
	mycam = hikGrab.hikkamera()
	mycam.init(serial=serial_number)
	mycam.set_exposure(t)
	mycam.set_gain(gain)
	mycam.set_framerate(fps)
	mycam.set_black_level(0)
	mycam.set_pixel_format('Mono12')
	mycam.set_Decimation(dec)
	return mycam


def get_back(camera, ser, Nframes, filename):
	ser.write('1'.encode())
	ser.readline()
	stt= time.time()
	mycam.getNframes(Nframes)

	av_im = mycam.sum_buff/Nframes
	hdu = asp.PrimaryHDU(data=av_im.astype(np.int16))
	hdr = hdu.header
	hdr.append(('TIME', f'{stt}'))
	hdr.append(('EXPOSURE', f'{t}'))
	hdr.append(('GAIN', f'{gain}'))
	hdr.append(('M2',caget('SAI25:M2')))
	hdu.writeto(filename, overwrite=True)

def make_servo_frames(start=9.2,end=9.6,nstep=10,t=5e4, gain=19, fps=50, dec=2,	delay = 0):

	ser = serial.Serial('/dev/ttyUSB0', 115200)
	mycam = init_camera(serial_number='DA1309692', t=t, gain=gain, fps=fps, dec=2)

	back_filename = f'./arktur_M2/background.fts'
	# get_back(camera=mycam, ser=ser, Nframes=10, filename=back_filename)

	# delay = int(input('delay: ')) 
	# inp = input('start, stop, number of points: ').split(' ')
	# print(inp)
	# n = int(inp[2])
	val_M2 = np.linspace(start, end, nstep + 1)
	for i, M2 in enumerate(val_M2):
		print(f'#{i}:\n')

		shef_ics.setFocus(M2, is_block=True)

		ser.write('2'.encode())
		decoded_response = ser.readline()
		print(f'response: {decoded_response}')
		time.sleep(1)	#wait for servo
			
		stt = time.time()
		mycam.getNframes(1)
		ser.write('1'.encode())
		decoded_response = ser.readline()
		print(f'response: {decoded_response}\n')
		   
		filename = f'./arktur_M2/my_image{stt}.fts'
		av_im = mycam.sum_buff
		hdu = asp.PrimaryHDU(data=av_im.astype(np.int16))
		hdr = hdu.header
		hdr.append(('TIME', f'{stt}'))
		hdr.append(('EXPOSURE', f'{t}'))
		hdr.append(('GAIN', f'{gain}'))
		hdr.append(('M2', caget('SAI25:M2')))
	#	   hdu2 = asp.CompImageHDU(data=av_im)
	#	   hdul = asp.HDUList([hdu1, hdu2])
		hdu.writeto(filename, overwrite=True)
		if delay > 0:
			time.sleep(delay)
	
	ser.close()
	mycam.exit()


if __name__ == "__main__":
	shef_ics.ocs_start_server()
	while shef_ics.ocs_client_connection == -1:
		print('wait ocs')
		time.sleep(1)
	t = 5e4
	gain = 19
	fps = 50

	ser = serial.Serial('/dev/ttyUSB0', 115200)
	mycam = init_camera(serial_number='DA1309692', t=t, gain=gain, fps=fps, dec=2)

	back_filename = f'./arktur_M2/background.fts'
	# get_back(camera=mycam, ser=ser, Nframes=10, filename=back_filename)


	delay = int(input('delay: ')) 
	inp = input('start, stop, number of points: ').split(' ')
	print(inp)
	n = int(inp[2])
	val_M2 = np.linspace(float(inp[0]), float(inp[1]), n + 1)
	for i, M2 in enumerate(val_M2):
		print(f'#{i}:\n')

		shef_ics.setFocus(M2, is_block=True)

		ser.write('2'.encode())
		decoded_response = ser.readline()
		print(f'response: {decoded_response}')
		time.sleep(1)	#wait for servo
			
		stt = time.time()
		mycam.getNframes(1)
		ser.write('1'.encode())
		decoded_response = ser.readline()
		print(f'response: {decoded_response}\n')
		   
		filename = f'./arktur_M2/my_image{stt}.fts'
		av_im = mycam.sum_buff
		hdu = asp.PrimaryHDU(data=av_im.astype(np.int16))
		hdr = hdu.header
		hdr.append(('TIME', f'{stt}'))
		hdr.append(('EXPOSURE', f'{t}'))
		hdr.append(('GAIN', f'{gain}'))
		hdr.append(('M2', caget('SAI25:M2')))
	#	   hdu2 = asp.CompImageHDU(data=av_im)
	#	   hdul = asp.HDUList([hdu1, hdu2])
		hdu.writeto(filename, overwrite=True)
		if delay > 0:
			time.sleep(delay)
	
	ser.close()
	mycam.exit()

 


